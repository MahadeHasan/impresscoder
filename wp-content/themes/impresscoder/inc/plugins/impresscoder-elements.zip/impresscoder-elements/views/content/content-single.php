<article <?php post_class() ?>>
    <?php impresscoder_framework_template('single/event-info'); ?>
</article>